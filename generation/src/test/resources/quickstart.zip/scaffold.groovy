scaffold {
    name 'Quickstart'
    description 'An empty Gradle project.'

    requiredContext {
        message 'The initial message...'
        artifactId 'A Maven like artifact id'
    }
}
