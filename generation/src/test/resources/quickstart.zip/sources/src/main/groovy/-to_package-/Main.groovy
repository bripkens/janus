package ${toPackage('example')};

class Main {
  static void main(String[] args) {
    println "Got started with " + args
  }
}