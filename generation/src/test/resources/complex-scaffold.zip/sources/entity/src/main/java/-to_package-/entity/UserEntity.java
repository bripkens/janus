package ${project.pckg}.entity;

import java.util.LinkedList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import ${project.pckg}.PasswordEncryptor;

/**
 *
 * @author Ben Ripkens <bripkens.dev@gmail.com>
 */
@Entity
@NamedQueries(value = {
    @NamedQuery(name = UserEntity.NAMED_QUERY.GET_BY_EMAIL,
    query = "SELECT u FROM UserEntity u WHERE u.email = :email")
})
public class UserEntity extends BaseEntity {

    @NotNull
    @Size(min = 3)
    @Pattern(regexp = "[a-zA-Z0-9-_ ]+")
    private String name;

    @NotNull
    private String password;

    @NotNull
    @Column(unique = true)
    // TODO add email validation
    private String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setClearTextPassword(String password) {
        this.password = PasswordEncryptor.encrypt(password);
    }

    public boolean isCorrectPassword(String plainPassword) {
        return PasswordEncryptor.checkPassword(this.password, plainPassword);
    }

    public interface NAMED_QUERY {
        String GET_BY_EMAIL = "UserEntity.byEmail";
    }
}
