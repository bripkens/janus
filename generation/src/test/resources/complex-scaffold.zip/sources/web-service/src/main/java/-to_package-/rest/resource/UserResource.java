package ${project.pckg}.rest.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import ${project.pckg}.entity.UserEntity;

/**
 *
 * @author Ben Ripkens <bripkens.dev@gmail.com>
 */
@Path("/users")
public class UserResource {
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public UserEntity getTestUser() {
        UserEntity user = new UserEntity();
        user.setName("John Doe");
        user.setEmail("john.doe@example.com");
        user.setClearTextPassword("12345");
        return user; 
    }
}
