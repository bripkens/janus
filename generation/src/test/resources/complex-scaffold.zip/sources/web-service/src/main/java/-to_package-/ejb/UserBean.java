package ${project.pckg}.ejb;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import ${project.pckg}.entity.UserEntity;

/**
 *
 * @author Ben Ripkens <bripkens.dev@gmail.com>
 */
@Stateless
@LocalBean
public class UserBean {
    
    @PersistenceContext
    private EntityManager entityManager;
    
    public UserEntity getByEmail(String email) {
        return entityManager
            .createNamedQuery(UserEntity.NAMED_QUERY.GET_BY_EMAIL,
                    UserEntity.class)
            .setParameter("email", email)
            .getSingleResult();
    }
    
    public UserEntity getByEmailOrNull(String email) {
        try {
            return getByEmail(email);
        } catch (NoResultException ex) {
            return null;
        }
    }

    public void register(UserEntity userEntity) {
        entityManager.persist(userEntity);
    }
    
    public UserEntity getById(String id) {
        return entityManager.find(UserEntity.class, id);
    }
}
