name 'RESTful web'
description 'Web based project with RESTeasy based web service'
